import os
import json
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_socketio import SocketIO, emit
from werkzeug.utils import secure_filename
import speech_recognition as sr
from pydub import AudioSegment
import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

# Initialize extensions
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Ensure upload directories exist
os.makedirs('uploads/audio', exist_ok=True)
os.makedirs('uploads/videos', exist_ok=True)
os.makedirs('data', exist_ok=True)

# Initialize data files
def init_data_files():
    default_data = {
        'projects': [],
        'transcripts': [],
        'research': [],
        'scripts': [],
        'storyboards': [],
        'comments': [],
        'users': [
            {
                'id': '1',
                'name': 'Alex Morgan',
                'role': 'Director/Writer',
                'avatar': 'https://i.pravatar.cc/150?img=12'
            }
        ]
    }
    
    for key in default_data:
        file_path = f'data/{key}.json'
        if not os.path.exists(file_path):
            with open(file_path, 'w') as f:
                json.dump(default_data[key], f, indent=2)

init_data_files()

# Helper functions for data management
def load_data(filename):
    try:
        with open(f'data/{filename}.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def save_data(filename, data):
    with open(f'data/{filename}.json', 'w') as f:
        json.dump(data, f, indent=2)

# File upload handling
ALLOWED_EXTENSIONS = {'mp3', 'wav', 'm4a', 'mp4', 'avi', 'mov'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# AI Services
class AIServices:
    @staticmethod
    def transcribe_audio(audio_path):
        """Transcribe audio file to text using speech recognition"""
        try:
            recognizer = sr.Recognizer()
            
            # Convert to WAV if needed
            if audio_path.endswith('.mp3'):
                audio = AudioSegment.from_mp3(audio_path)
                audio_path = audio_path.replace('.mp3', '.wav')
                audio.export(audio_path, format='wav')
            
            with sr.AudioFile(audio_path) as source:
                audio_data = recognizer.record(source)
                text = recognizer.recognize_google(audio_data)
                
            return text
        except Exception as e:
            return f"Transcription error: {str(e)}"
    
    @staticmethod
    def generate_script_suggestions(script_text):
        """Generate AI suggestions for script improvement"""
        suggestions = [
            "Consider adding more descriptive action lines to enhance visual storytelling.",
            "The dialogue could reveal more about the character's background and motivations.",
            "Add sensory details to create a more immersive experience for the audience.",
            "This scene could benefit from more subtext in the character interactions.",
            "Consider varying sentence structure to create better rhythm in the dialogue."
        ]
        return suggestions
    
    @staticmethod
    def analyze_research_content(content):
        """Analyze research content and generate insights"""
        insights = [
            "This research aligns well with your project's themes of technology and humanity.",
            "Consider how these findings could influence your character development.",
            "This material could provide background for your story's world-building."
        ]
        return insights

# API Routes
@app.route('/')
def index():
    return jsonify({
        "message": "AI-Powered Pre-Production Studio API",
        "version": "1.0",
        "endpoints": {
            "projects": "/api/projects",
            "research": "/api/research",
            "transcripts": "/api/transcripts",
            "scripts": "/api/scripts",
            "storyboards": "/api/storyboards",
            "collaboration": "/api/comments"
        }
    })

# Projects API
@app.route('/api/projects', methods=['GET', 'POST'])
def handle_projects():
    if request.method == 'GET':
        projects = load_data('projects')
        return jsonify(projects)
    
    elif request.method == 'POST':
        data = request.json
        project = {
            'id': str(uuid.uuid4()),
            'title': data.get('title', 'Untitled Project'),
            'description': data.get('description', ''),
            'genre': data.get('genre', 'documentary'),
            'progress': 0,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        projects = load_data('projects')
        projects.append(project)
        save_data('projects', projects)
        
        return jsonify(project), 201

# Research API
@app.route('/api/research', methods=['GET', 'POST'])
def handle_research():
    if request.method == 'GET':
        research = load_data('research')
        return jsonify(research)
    
    elif request.method == 'POST':
        data = request.json
        research_item = {
            'id': str(uuid.uuid4()),
            'title': data.get('title', ''),
            'content': data.get('content', ''),
            'tags': data.get('tags', []),
            'type': data.get('type', 'article'),
            'created_at': datetime.now().isoformat(),
            'ai_insights': AIServices.analyze_research_content(data.get('content', ''))
        }
        
        research = load_data('research')
        research.append(research_item)
        save_data('research', research)
        
        return jsonify(research_item), 201

# Transcripts API
@app.route('/api/transcripts', methods=['GET', 'POST'])
def handle_transcripts():
    if request.method == 'GET':
        transcripts = load_data('transcripts')
        return jsonify(transcripts)
    
    elif request.method == 'POST':
        # Handle file upload
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'audio', filename)
            file.save(file_path)
            
            # Transcribe audio
            transcript_text = AIServices.transcribe_audio(file_path)
            
            transcript = {
                'id': str(uuid.uuid4()),
                'filename': filename,
                'transcript': transcript_text,
                'duration': '00:05:00',  # This would be calculated in real implementation
                'created_at': datetime.now().isoformat()
            }
            
            transcripts = load_data('transcripts')
            transcripts.append(transcript)
            save_data('transcripts', transcripts)
            
            return jsonify(transcript), 201
        
        return jsonify({'error': 'Invalid file type'}), 400

# Scripts API
@app.route('/api/scripts', methods=['GET', 'POST', 'PUT'])
def handle_scripts():
    if request.method == 'GET':
        scripts = load_data('scripts')
        return jsonify(scripts)
    
    elif request.method == 'POST':
        data = request.json
        script = {
            'id': str(uuid.uuid4()),
            'title': data.get('title', 'Untitled Script'),
            'content': data.get('content', ''),
            'genre': data.get('genre', ''),
            'ai_suggestions': AIServices.generate_script_suggestions(data.get('content', '')),
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        scripts = load_data('scripts')
        scripts.append(script)
        save_data('scripts', scripts)
        
        return jsonify(script), 201
    
    elif request.method == 'PUT':
        data = request.json
        script_id = data.get('id')
        
        scripts = load_data('scripts')
        for script in scripts:
            if script['id'] == script_id:
                script['content'] = data.get('content', script['content'])
                script['ai_suggestions'] = AIServices.generate_script_suggestions(data.get('content', ''))
                script['updated_at'] = datetime.now().isoformat()
                save_data('scripts', scripts)
                return jsonify(script)
        
        return jsonify({'error': 'Script not found'}), 404

# Storyboards API
@app.route('/api/storyboards', methods=['GET', 'POST'])
def handle_storyboards():
    if request.method == 'GET':
        storyboards = load_data('storyboards')
        return jsonify(storyboards)
    
    elif request.method == 'POST':
        data = request.json
        storyboard = {
            'id': str(uuid.uuid4()),
            'title': data.get('title', ''),
            'description': data.get('description', ''),
            'scene_number': data.get('scene_number', 1),
            'visual_references': data.get('visual_references', []),
            'notes': data.get('notes', ''),
            'created_at': datetime.now().isoformat()
        }
        
        storyboards = load_data('storyboards')
        storyboards.append(storyboard)
        save_data('storyboards', storyboards)
        
        return jsonify(storyboard), 201

# Collaboration API
@app.route('/api/comments', methods=['GET', 'POST'])
def handle_comments():
    if request.method == 'GET':
        comments = load_data('comments')
        return jsonify(comments)
    
    elif request.method == 'POST':
        data = request.json
        comment = {
            'id': str(uuid.uuid4()),
            'user_id': data.get('user_id', '1'),
            'content': data.get('content', ''),
            'target_type': data.get('target_type', 'script'),  # script, storyboard, research, etc.
            'target_id': data.get('target_id', ''),
            'created_at': datetime.now().isoformat()
        }
        
        comments = load_data('comments')
        comments.append(comment)
        save_data('comments', comments)
        
        # Emit real-time update via Socket.IO
        socketio.emit('new_comment', comment)
        
        return jsonify(comment), 201

@app.route('/api/users', methods=['GET'])
def handle_users():
    users = load_data('users')
    return jsonify(users)

# Real-time collaboration with Socket.IO
@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('connected', {'message': 'Connected to pre-production studio'})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@socketio.on('script_update')
def handle_script_update(data):
    """Handle real-time script editing"""
    emit('script_updated', data, broadcast=True, include_self=False)

@socketio.on('join_project')
def handle_join_project(data):
    """Handle users joining project rooms"""
    project_id = data.get('project_id')
    emit('user_joined', data, room=project_id, broadcast=True)

# Serve the frontend
@app.route('/<path:path>')
def serve_frontend(path):
    return send_from_directory('.', path)

if __name__ == '__main__':
    print("Starting AI-Powered Pre-Production Studio Server...")
    print("Access the application at: http://localhost:5000")
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)